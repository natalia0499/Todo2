<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$taskIDs = $_GET['taskIDs'];
$user_id = $_GET['user_id'];

if (!empty($taskIDs)) {
    $sql = "DELETE FROM tasks WHERE id IN ($taskIDs)";
    $conn->query($sql);
}

$sql = "SELECT id, name FROM tasks WHERE user_id = $user_id";
$result = $conn->query($sql);
$tasks = [];
$sql = "SELECT id, name FROM tasks WHERE user_id = $user_id"; 
$result = $conn->query($sql);
print_r($result);

    while ($row = $result->fetch_assoc()) {
        array_push($tasks, $row);
    }



foreach ($tasks as $task) {
    echo '<div class="box task">' . $task['name'] . '
        <div class="removeTask" onclick="removeTask(this)" data-task="' . $task['id'] . '">X</div>
    </div>';
}

mysqli_close($conn);
?>
