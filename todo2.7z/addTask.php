<?php
$zadania = [];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";
$taskName = $_GET['taskName'];
$user_id = $_GET['user_id'];


$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
  echo "błąd";
    die("Connection failed: " . mysqli_connect_error());
}

$sql_addtask = "INSERT INTO `tasks`(`name`,`user_id`) VALUES ('$taskName','$user_id');";

$addtask = $conn->query($sql_addtask);


?>



