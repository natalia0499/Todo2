
<?php
$tasks = [];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";
$user_id = 2;


$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$user_login = 2;
$sql = "SELECT id, name FROM tasks WHERE user_id = $user_id;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 
    while($row = $result->fetch_assoc()) {

   array_push($tasks, $row);
    }
  } else {
    echo "0 results";
  }

?>
<div id="tasks">
<?php

foreach($tasks as $task){
  require 'templates/task.php';
    // print_r($task);

}
?>
</div>
</div>
<div class="add">
<input type="text" id="inputZadanie">

<select id="userList">
    <option value="">Wybierz użytkownika</option>
</select>
<button id="button" onclick="addTask()">Dodaj</button> 


</div>
<div class="remove">
<button id="buttonRemoveSelectedTasks" onclick="removeTasks()">Usuń zaznaczone</button>
</div>
