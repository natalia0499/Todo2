<?php
$id_zadania = $task['id'];
$nazwa_zadania = $task['name'];
echo '<div class="box task" data-task="' . $id_zadania . '">' . $nazwa_zadania . '
<div class="removeTask" onclick="removeTask(this)" data-task="' . $id_zadania . '">X</div>
<input type="checkbox">
</div>';

?>
