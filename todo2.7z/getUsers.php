<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql_users = "SELECT user_id, name FROM users;";
$result_users = $conn->query($sql_users);

if ($result_users->num_rows > 0) {
    while ($row = $result_users->fetch_assoc()) {
        echo "<option value='" . $row['user_id'] . "'>" . $row['name'] . "</option>";
    }
} else {
    echo "<option value=''>Brak użytkowników</option>";
}

$conn->close();
?>
