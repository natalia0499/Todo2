document.addEventListener("DOMContentLoaded", function() {
    const tasks = document.querySelectorAll('.task');
    tasks.forEach(task => {
        const taskId = task.getAttribute('data-task');
        console.log('Task ID:', taskId);
    });

    fetch('getUsers.php')
        .then(response => response.text())
        .then(data => {
            document.getElementById('userList').innerHTML += data;
        });
});

function addTask() {
    const taskName = document.getElementById("inputZadanie").value;
    const userId = document.getElementById("userList").value;

    if (taskName === "" || userId === "") {
      
    } else {
        const ajax = new XMLHttpRequest();
        ajax.onload = function() {
            if (this.status === 200) {
                document.getElementById("tasks").innerHTML = this.responseText;

                const tasks = document.querySelectorAll('.task');
                tasks.forEach(task => {
                    const taskId = task.getAttribute('data-task');
                    console.log('Task ID:', taskId);
                });
            } else {
                console.error('Nie udało się dodać zadania');
            }
        };
        ajax.open("GET", "addTask.php?taskName=" + taskName + "&user_id=" + userId);
        ajax.send();
    }
}

function removeTask(element) {
    const taskID = element.getAttribute('data-task');
    const userId = document.getElementById("userList").value;
    console.log(taskID);
    console.log(userId);

    const ajax = new XMLHttpRequest();
    ajax.onload = function() {
        if (this.status === 200) {
            element.parentElement.remove();
        }
    };
    ajax.open("GET", "removeTask.php?taskID=" + taskID + "&user_id=" + userId);
    ajax.send();
}

function removeTasks() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    const userId = document.getElementById("userList").value;
    const taskIds = [];

    checkboxes.forEach(checkbox => {
        taskIds.push(checkbox.parentElement.getAttribute('data-task'));
    });

    sendAjaxRequest(taskIds, userId);
}

function sendAjaxRequest(taskIds, userId) {
    const taskIdsString = taskIds.join(',');  
    const ajax = new XMLHttpRequest();
    ajax.onload = function() {
        if (this.status === 200) {
            document.getElementById("tasks").innerHTML = this.responseText;
        }
    };
    ajax.open("GET", "removeTasks.php?user_id=" + userId + "&taskIDs" + taskIdsString);
    ajax.send();
}

function getTaskId(item) {
    console.log(item.parentElement.getAttribute('data-task'));
}

const button = document.getElementById("button");
button.addEventListener("click", sendForm);

function sendForm() {
    const inputZadanie = document.getElementById("inputZadanie");
    const userList = document.getElementById("userList");
    let inputErrors = 0;

    if (inputZadanie.value === "") {
        inputZadanie.classList.add("error");
        inputErrors += 1;
    } else {
        inputZadanie.classList.remove("error");
    }

    if (userList.value === "") {
        userList.classList.add("error");
        inputErrors += 1;
    } else {
        userList.classList.remove("error");
    }

    if (inputErrors === 0) {
        addTask();
    }

    console.log(inputErrors);
}
