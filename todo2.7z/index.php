<?php
require('header.php');
require('tablica.php');
require('footer.php');
?>
