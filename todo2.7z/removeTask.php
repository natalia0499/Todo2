<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";
$taskID = $_GET['taskID'];
$user_id = $_GET['user_id'];


$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    echo "błąd";
    die("Connection failed: " . mysqli_connect_error());
}

$sql_removeTask = "DELETE FROM tasks WHERE id = '$taskID'";
$removetask = $conn->query($sql_removeTask);

$tasks = [];
$sql = "SELECT id, name FROM tasks WHERE user_id = $user_id"; 
$result = $conn->query($sql);
/*if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        array_push($tasks, $row);
    }
} else {
    echo "0 results";
}*/


foreach ($tasks as $task) {
    echo '<div class="box task">' . $task['name'] . '
        <div class="removeTask" onclick="removeTask(this)" data-task="' . $task['id'] . '">X</div>
    </div>';
}

mysqli_close($conn);
?>