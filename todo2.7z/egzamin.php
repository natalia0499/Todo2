<?php
/*
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";

$conn = mysqli_connect($servername, $username, $password, $dbname);
$zadania = $conn->query("SELECT * FROM tasks");
echo "<table border='1'>";
echo "<thead><tr><th>id</th><th>name</th><th>user_id</th></tr></thead>";
while($row = $zadania->fetch_assoc()){
    /*echo "<pre>";
   print_r($row);
   echo "</pre>";


  echo '<tr data-id="' . $row['user_id'] . '">';
  echo "<td>".$row['id']. "</td>";
  echo "<td>".$row['name']. "</td>";
  echo "<td>".$row['user_id']. "</td>";
  echo "</tr>";
}
echo "</table>";

$conn->close();

?>
<script>

    var wiersze = document.querySelectorAll('tr');
    console.log(wiersze);
   
    wiersze.forEach(zakresl);
    function zakresl(wiersz){
        
        //var userId = wiersz.querySelector("td:last-of-type").innerHTML;
        var userId = wiersz.getAttribute("data-id");
        if(userId === "1"){
            //wiersz.classList.add("podkreslone");
            wiersz.style.color = "red";
            wiersz.style.fontWeight = "bold";
        }

        console.log(userId);
         
    }
  

    
</script>
<style>
    .podkreslone{
        border: 1px red solid;
    }
</style>
   */ 
