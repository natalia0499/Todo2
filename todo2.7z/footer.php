<div class="container" >
<div class="tasks-counter">
<?php




$liczba_elementow = count($tasks);
echo "Masz $liczba_elementow zadań";
?>
</div>
</div>


<script src="assets/js/ajax.js"></script>

</body>






